PAPER FLIGHT v0.9

Upload index.html and version.json together to your website.
To publish the next version, update APP_VERSION in index.html and version in version.json to the same new version, then edit title, summary and notes. Deploy both files together. Netlify connected to GitHub can redeploy automatically on each push.
The website checks version.json every 60 seconds and offers to reload when a newer version is detected. On first load of a new version, the patch notes popup appears. On a file:// preview, bundled notes work but online checks are unavailable.
Keep browser save keys unchanged to preserve player progress.
